package ctagsanalyzer;

import java.io.*;
import java.util.*;

public class CtagsAnalyzer {
    public static void main(String[] args) {
        // Provide the correct path to the ctags file and target source file
        String tagsFilePath = "C:\\Users\\pc\\Downloads\\tools\\tools\\ctags\\tags"; 
        String targetSourceFile = "C:\\Users\\pc\\Downloads\\tools\\tools\\ctags\\DepthMap.java";

        // Process the ctags file
        try (BufferedReader reader = new BufferedReader(new FileReader(tagsFilePath))) {
            String line;

            System.out.println("Methods and their Starting Lines from DepthMap.java:\n");

            while ((line = reader.readLine()) != null) {
                // Skip metadata lines (lines starting with !_)
                if (line.startsWith("!_")) {
                    continue;
                }

                // Split the line by tab characters
                String[] parts = line.split("\t");

                // Ensure the line has the expected number of parts
                if (parts.length >= 4) {
                    String tagName = parts[0]; // Method name
                    String fileName = parts[1]; // File path
                    String lineNumberStr = parts[2].replaceAll("[^0-9]", ""); // Clean line number
                    String tagType = parts[3].split(":")[0]; // Extract the tag type (e.g., "m")

                    // Check if the tag type is "m" (method) and the file matches DepthMap.java
                    if (tagType.equals("m") && fileName.endsWith("DepthMap.java")) {
                        int lineNumber = Integer.parseInt(lineNumberStr);

                        // Retrieve the actual line from DepthMap.java
                        String codeLine = getLineFromFile(targetSourceFile, lineNumber);
                        System.out.println("Method: " + tagName + ", Line " + lineNumber + ": " + codeLine);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves a specific line from the file.
     * @param filePath Path to the file.
     * @param lineNumber Line number to retrieve.
     * @return The content of the line, or an error message.
     */
    private static String getLineFromFile(String filePath, int lineNumber) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            int currentLine = 0;

            while ((line = reader.readLine()) != null) {
                currentLine++;
                if (currentLine == lineNumber) {
                    return line.trim(); // Return the desired line
                }
            }
        } catch (IOException e) {
            return "[Error reading file: " + filePath + "]";
        }
        return "[Line " + lineNumber + " not found in " + filePath + "]";
    }
}

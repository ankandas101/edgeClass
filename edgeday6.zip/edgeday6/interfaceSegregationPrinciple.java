package edgeday6;

public class interfaceSegregationPrinciple {
    public static void main(String[] args) {
    
    student std = new student();
    std.showStudentID(101);
    std.showDiscipline("CSE");
    
    
    teacher ts = new teacher();
    ts.showSubject("CSE");
    ts.showDiscipline("CSE");
    
    }
}

interface functions{
    void showStudentID(int id);
    void showSubject(String sub);
    void showDiscipline(String dis);
}

interface fun1{
    void showStudentID(int id);
}

interface fun2{
    void showSubject(String sub);
}

interface fun3{
    void showDiscipline(String dis);
}

class student implements fun1, fun3{
    public void showStudentID(int id){
        System.out.println("Student ID: "+id);
    }
    
    public void showDiscipline(String dis){
        System.out.println("Discipline: " + dis);
    }
}

class teacher implements fun2, fun3{
    
    @Override
    public void showSubject(String sub){
        System.out.println("Subject: " + sub);
    }
    public void showDiscipline(String dis){
           System.out.println("Discipline: " + dis);
       }
 
}

package edgeday3;
public class factoryOperation {
    
 public operation calculate(float x , float y,int op){
     if(op == 0){
         addition add = new addition();
         add.a = x;
         add.b = y;
         return add;
     } else{
     subtraction sub = new subtraction();
     sub.a = x;
     sub.b = y;
     
     return sub;
    }
 }
}

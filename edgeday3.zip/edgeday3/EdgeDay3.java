package edgeday3;

public class EdgeDay3 {

    public static void main(String[] args) {
    
        factoryOperation f = new factoryOperation();
        
        operation obj1 = f.calculate(2, 2, 0);
        operation obj2 = f.calculate(5, 2, 1);
        
        obj1.show();
        obj2.show();
    }
    
}

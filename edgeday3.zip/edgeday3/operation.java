package edgeday3;

public class operation {
    float a ;
    float b ;
   public void show(){}
}

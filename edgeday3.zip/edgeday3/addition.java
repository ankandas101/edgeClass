
package edgeday3;

public class addition extends operation{
    public void show(){ 
        System.out.println("Sum = "+ (a+b) ); 
   }
    
}

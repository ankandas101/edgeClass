package edgeday3;
public class subtraction extends operation{
    public void show(){
        System.out.println("Sub = "+ (a-b) ); 
   }
}

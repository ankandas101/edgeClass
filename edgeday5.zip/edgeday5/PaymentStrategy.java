
package edgeday5;

/**
 *
 * @author pc
 */
public interface PaymentStrategy {
        public void foodIteam (float original_money);          
        public void nonFoodIteam (float original_money);
}
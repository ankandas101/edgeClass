package edgeday5;

public class ShoppingCart {
    float price;
    public void pay( PaymentStrategy ps )
    {
        ps.foodIteam(price);
        ps.nonFoodIteam(price);
    }
}

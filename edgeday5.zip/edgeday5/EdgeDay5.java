package edgeday5;

public class EdgeDay5 {

    public static void main(String[] args) {
    
       ShoppingCart sc = new ShoppingCart ();
        sc.price = 15000.0f;
        sc.pay (new TeacherPaymentStrategy ());
        
        sc.pay (new StudentPaymentStrategy ());
        
        sc.pay (new StaffPaymentStrategy ());

    }
    
}

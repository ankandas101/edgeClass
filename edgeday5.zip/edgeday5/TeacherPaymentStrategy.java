package edgeday5;

public class TeacherPaymentStrategy implements PaymentStrategy{
     public void foodIteam(float original_money)
    {
        float payment = original_money * 0.2f;
        System.out.println ("Food Iteam Price: " + payment);
    }
     public void nonFoodIteam(float original_money)
    {
        float payment = original_money * 0.1f;
        System.out.println ("Non Food Iteam Price: " +payment);
    }
}
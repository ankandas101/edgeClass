
package edgeday5;

/**
 *
 * @author pc
 */
public class StudentPaymentStrategy implements PaymentStrategy{
    public void foodIteam (float original_money)
    {
        float payment = original_money * 0.10f;
        System.out.println ("Food Iteam Price: " +payment);  
    }
    
    public void nonFoodIteam (float original_money)
    {
        float payment = original_money * 0.5f;
        System.out.println ("Non Food Iteam Price: " +payment);        
    }

}


package com.mycompany.edgeday1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author ankan
 */

public class ManualAddition {
    
    // Function to add two numbers manually, digit by digit
    public static String addNumbers(int num1, int num2) {
        ArrayList<Integer> resultDigits = new ArrayList<>();
        int carry = 0;

        // Loop until both numbers are fully processed
        while (num1 > 0 || num2 > 0 || carry > 0) {
            // Get the last digit of each number
            int digit1 = num1 % 10;
            int digit2 = num2 % 10;

            // Add digits and the carry
            int sum = digit1 + digit2 + carry;
            resultDigits.add(sum % 10);  // Store the result digit
            carry = sum / 10;            // Update carry

            // Move to the next significant digit
            num1 /= 10;
            num2 /= 10;
        }

        // Reverse the list to get the correct order
        Collections.reverse(resultDigits);
        
        // Build the result string from the list of digits
        StringBuilder result = new StringBuilder();
        for (int digit : resultDigits) {
            result.append(digit);
        }
        
        return result.toString();
    }

    // Main function
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input two numbers
        System.out.print("Enter the first number: ");
        int number1 = scanner.nextInt();

        System.out.print("Enter the second number: ");
        int number2 = scanner.nextInt();

        // Perform the addition using the manual addition function
        String result = addNumbers(number1, number2);

        // Display the result in vertical addition format
        System.out.printf("%8d\n", number1);
        System.out.printf("+%7d\n", number2);
        System.out.println("--------");
        System.out.printf("%8s\n", result);

        scanner.close();
    }
}


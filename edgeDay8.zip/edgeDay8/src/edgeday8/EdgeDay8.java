package edgeday8;

public class EdgeDay8 {

    public static void main(String[] args) {
    int a = 5;
    int b = 3;
    
    }
    
    
   
   
}
package edgeday8;

class A extends Parent{
    public void method1(int a,int b){
       if(a>b){
       }
   }
}
class B extends Parent{
    public void method2(int a,int b){
       if(a>b){
              marge(a,b);
       }
   }
}

class C {
    public void marge(int a,int b){
      for(int i=a; i<=b;i++){
               System.out.println(i);
           }
    }
}
class Parent extends C{

}
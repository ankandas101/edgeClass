package edgeday9;

public class lamdaExpression {
    
}

interface myInt{
    
    void function(int x);
}
package edgeday4;

public class EdgeDay4 {
    
    public static void main(String[] args) {
        factory f = new factory ();
       
        addFactory af = new addFactory (5,4);
        subFactory sf = new subFactory (5,1);
        
        triSumFactory df = new triSumFactory (6,2,3);
        divFactory divf = new divFactory (6,2);
        
        operation op1 = f.make (af);
        operation op2 = f.make (sf);
        
        operation op3 = f.make (df);
        operation op4 = f.make (divf);
        
       
        op1.show ();
        op2.show ();
        op3.show ();
        op4.show ();
        
    }
    
}


package edgeday4;

public class factory {
       public operation make(absfactory absf)
    {
        return absf.make();
    }
}

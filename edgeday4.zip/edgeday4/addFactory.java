
package edgeday4;

class addFactory implements absfactory
{
   float a ,b;
   
    addFactory (float x, float y) { this.a = x; this.b = y; }
   
    public addition make()
    {
        addition add = new addition();
        add.a = this.a;
        add.b = this.b;
        return add;
    }
}

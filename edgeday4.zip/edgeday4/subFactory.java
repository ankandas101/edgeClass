
package edgeday4;

class subFactory implements absfactory
{
    float a,b;
   
    subFactory (float x, float y) { this.a = x; this.b = y;}
   
    
    public subtraction make()
    {
        subtraction sub = new subtraction();
        sub.a = this.a;
        sub.b = this.b;
        return sub;
    }
}
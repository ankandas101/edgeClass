
package edgeday4;

/**
 *
 * @author pc
 */
public class triSumFactory  implements absfactory{
       float a ,b,c;
   
    triSumFactory (float x, float y, float z) { this.a = x; this.b = y;this.c = z; }
   
    public triSum make()
    {
        triSum triSm = new triSum();
        triSm.a = this.a;
        triSm.b = this.b;
        triSm.c = this.c;
        
        return triSm;
    }
}

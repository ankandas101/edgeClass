
package edgeday4;

/**
 *
 * @author pc
 */
public class divFactory  implements absfactory{
       float a ,b,c;
   
    divFactory (float x, float y) { this.a = x; this.b = y;}
   
    public division make()
    {
        division div = new division();
        div.a = this.a;
        div.b = this.b;
        
        return div;
    }
}

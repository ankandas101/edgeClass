
package edgeday4;

public interface operation {
     void show ();
}

class addition implements operation
{
    float a ,b;
   
    public void show ()
    {
     System.out.println (a + " + "+ b  +" = " + (a+b));
    }
}

class subtraction implements operation
{
    float a ,b;
   
    public void show ()
    {
       System.out.println (a + " - "+ b  +" = " + (a-b));
    }
}

class triSum implements operation
{
    float a ,b,c;
   
    public void show ()
    {
       System.out.println (a + " + "+ b + " + "+ c +" = " + (a+b+c) );
    }
}

class division implements operation
{
    float a ,b;
   
    public void show ()
    {
       System.out.println (a + " / " + b + " = " + (a/b) );
    }
}
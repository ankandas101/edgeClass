package edgeday4;

public interface absfactory {
     operation make();
}

